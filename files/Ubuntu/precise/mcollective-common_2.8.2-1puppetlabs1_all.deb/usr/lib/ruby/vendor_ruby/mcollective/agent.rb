module MCollective
  module Agent

  end
end
