# -*- encoding: utf-8 -*-

module Stomp

  # Define the gem version.
  module Version  #:nodoc: all
    MAJOR = 1
    MINOR = 3
    PATCH = 2
    STRING = "#{MAJOR}.#{MINOR}.#{PATCH}"
  end
end
